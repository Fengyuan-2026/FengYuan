#!/usr/bin/env python3
"""公开子样本第一阶段复现：评价已有预测，不训练模型。

运行 python run_replication.py；所有输入只读，结果写入 results/、figures/。
依赖 numpy pandas scipy scikit-learn matplotlib，不依赖 statsmodels / torch。
原始算法按随附三个 notebook 重写；明确的公式修正与假设性敏感性分开。
"""
from __future__ import annotations

import argparse
import ast
import base64
import hashlib
import html
import importlib.metadata
import json
import platform
from pathlib import Path

import numpy as np
import pandas as pd
from scipy import stats
from sklearn.linear_model import LogisticRegression
from sklearn.neighbors import NearestNeighbors
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

METHODS = ['OPT', 'E2E_RNN', 'Bm1', 'Bm2', 'Normal', 'Gamma', 'gbm']
METRICS = ['holding_cost', 'stockout_cost', 'total_cost', 'turnover', 'stockout_rate']
PAPER_OFFLINE = {
    'OPT': [3022.60, 1925.70, 1096.91],
    'E2E_RNN': [3766.52, 2689.02, 1077.50],
    'Bm1': [4207.09, 2502.55, 1704.54],
    'Bm2': [4157.03, 2254.99, 1902.04],
    'Normal': [4576.05, 3369.21, 1206.84],
    'Gamma': [4476.17, 2821.87, 1654.30],
    'gbm': [4017.82, 2109.93, 1907.89],
}
SAVED_OFFLINE = [2572.964327, 3036.758343, 3842.305332, 3837.828539,
                 3961.691600, 4099.949751, 3424.869965]
PROFILES = {
    'original': dict(paper_normal=False, clip=False, carry_backlog=False),
    'normal_eq7_only': dict(paper_normal=True, clip=False, carry_backlog=False),
    'nonnegative_only': dict(paper_normal=False, clip=True, carry_backlog=False),
    'full_backlog_only': dict(paper_normal=False, clip=False, carry_backlog=True),
    'combined_diagnostic': dict(paper_normal=True, clip=True, carry_backlog=True),
}


def write_csv(df, path):
    """UTF-8 BOM 便于 Windows Excel 直接打开；保留浮点精度。"""
    df.to_csv(path, index=False, encoding='utf-8-sig', float_format='%.12g')


def numeric_list(value):
    return np.asarray(ast.literal_eval(value), dtype=float)


def load_offline(data_dir):
    df = pd.read_csv(data_dir / 'df_test.csv')
    df['sf_rnn'] = df.sf_rnn.map(numeric_list)
    df['demand_hist'] = df.demand_hist.map(
        lambda x: np.fromstring(x.strip('[]'), sep=' '))
    assert len(df) == 3000 and df.SKU.nunique() == 2607
    return df


def predictions(df, paper_normal=False):
    """严格保留原 notebook BM1/BM2/Gamma 计算；Normal 可切换公式7。

    注意：这里的 *_pred 后续按目标库存水平使用，与 README“订货量”
    解释存在冲突。本程序保留该语义以复算，不据此证明它正确。
    """
    x = df.copy()
    mean_forecast = x.sf_rnn.map(np.mean)
    rl = x.review_period + x.vlt
    x['Bm1_pred'] = mean_forecast * rl.astype(int)
    days = [int(r) if r <= 9 else int(r) - r // 10 for r in rl]
    x['Bm2_pred'] = mean_forecast * days
    if paper_normal:
        variance = ((x.review_period + x.vendor_vlt_mean) * x.demand_std**2
                    + x.demand_mean**2 * x.vendor_vlt_std**2)
        z = stats.norm.ppf(.9)
    else:
        variance = ((x.review_period + x.vendor_vlt_mean) * x.demand_std**2
                    + x.demand_std**2 * x.vendor_vlt_std)
        z = 1.64
    x['Normal_pred'] = (x.demand_mean * (x.review_period + x.vendor_vlt_mean)
                        + z * np.sqrt(variance)).astype(int)
    def gamma_base(row):
        theta = row.demand_std**2 / (row.demand_mean + 1e-4)
        k = row.demand_mean / (theta + 1e-4)
        value = stats.gamma.ppf(.9,
            a=int(row.review_period + row.vendor_vlt_mean) * k, scale=theta)
        return 0 if np.isnan(value) else int(value)
    x['Gamma_pred'] = x.apply(gamma_base, axis=1)
    return x


def simulate_original_group(x, method, clip=False, carry_backlog=False):
    """重现 E2E_Section4 cell 11 的窗口、索引和到货规则。

    仅 clip / carry_backlog 两个开关改变指定行为，其他规则不动。
    不把本函数称为论文全欠货环境：其计费窗口、预测提前期等仍待核实。
    """
    inv1, inv2 = [x['initial_stock'][0]], []
    n_rounds = len(x['OPT_pred'])
    diagnostics = {'negative_raw_orders': 0, 'negative_applied_orders': 0,
                   'index_fallbacks': 0, 'orders': 0}
    for r in range(n_rounds):
        n_days = len(x['demand_hist'][r]) - (r < n_rounds - 1)
        lead = int(round(x['vlt'][r]))
        for t in range(n_days):
            if t == 0:
                if r == 0:
                    replen = int(round(x[method + '_pred'][r] - inv1[0]))
                else:
                    try:
                        replen = int(round(x[method + '_pred'][r] - inv1[-lead-1]))
                    except IndexError:
                        diagnostics['index_fallbacks'] += 1
                        replen = int(round(x[method + '_pred'][r] - inv1[1]))
                diagnostics['orders'] += 1
                diagnostics['negative_raw_orders'] += replen < 0
                if clip:
                    replen = max(replen, 0)
                diagnostics['negative_applied_orders'] += replen < 0
            if t < lead:
                if r == 0:
                    inv1.append(inv1[-1] - x['demand_hist'][r][t])
            elif t == lead:
                before = inv1[-1] if (carry_backlog or inv1[-1] >= 0) else 0
                inv = before + replen - x['demand_hist'][r][t]
                inv1.append(inv)
                inv2.append(inv)
            else:
                inv = inv1[-1] - x['demand_hist'][r][t]
                inv1.append(inv)
                inv2.append(inv)
    arr = np.asarray(inv2)
    holding, shortage = np.maximum(arr, 0).sum(), 9 * np.maximum(-arr, 0).sum()
    return dict(holding_cost=holding, stockout_cost=shortage,
                total_cost=holding + shortage, billed_points=len(inv2),
                full_points=len(inv1)-1, **diagnostics)


def offline_analysis(raw, results):
    records = []
    for profile, settings in PROFILES.items():
        df = predictions(raw, settings['paper_normal'])
        groups = df.groupby('SKU', sort=True).agg(lambda s: s.tolist())
        for sku, x in groups.iterrows():
            for method in METHODS:
                records.append(dict(profile=profile, SKU=sku, method=method,
                    **simulate_original_group(x, method, settings['clip'],
                                               settings['carry_backlog'])))
        print('offline finished:', profile, flush=True)
    detail = pd.DataFrame(records)
    summary = detail.groupby(['profile', 'method'], sort=False)[
        ['total_cost', 'holding_cost', 'stockout_cost']].mean().reset_index()
    original = summary[summary.profile == 'original'].set_index('method').loc[METHODS]
    for j, col in enumerate(['total_cost', 'holding_cost', 'stockout_cost']):
        original['paper_' + col] = [PAPER_OFFLINE[m][j] for m in METHODS]
    original['difference_from_paper_total'] = original.total_cost-original.paper_total_cost
    checks = []
    for method, expected in zip(METHODS, SAVED_OFFLINE):
        actual = original.loc[method, 'total_cost']
        passed = bool(np.isclose(actual, expected, atol=1e-5, rtol=0))
        checks.append(dict(check='saved_notebook_total_' + method,
                           expected=expected, actual=actual, passed=passed))
        assert passed, (method, actual, expected)
    assert np.allclose(detail.total_cost, detail.holding_cost+detail.stockout_cost)
    assert (detail.loc[detail.profile.isin(['nonnegative_only', 'combined_diagnostic']),
                       'negative_applied_orders'] == 0).all()
    write_csv(detail, results/'offline_per_sku.csv')
    write_csv(summary, results/'offline_profiles.csv')
    write_csv(original.reset_index(), results/'offline_original_vs_paper.csv')
    diag = detail.groupby(['profile', 'method'], sort=False)[
        ['negative_raw_orders', 'negative_applied_orders', 'index_fallbacks',
         'orders', 'billed_points', 'full_points']].sum().reset_index()
    write_csv(diag, results/'offline_diagnostics.csv')
    return summary, original.reset_index(), diag, checks


def load_field(data_dir):
    output = []
    quality = []
    for group, tag in [('treatment','e2e'), ('control','jd')]:
        for period in ['pre','post']:
            df = pd.read_csv(data_dir/f'order_{tag}_{period}_500.csv')
            assert len(df)==500 and df.sku_dc_pair_index.is_unique
            for row in df.itertuples(index=False):
                inv, demand = numeric_list(row.test_inv), numeric_list(row.test_demand)
                used = inv[:-1]   # 保留原代码口径，不猜测每个库存点对应的日期。
                raw_turnover = row.ave_inv / row.ave_demand
                output.append(dict(group=group, period=period,
                    pair_id=int(row.sku_dc_pair_index),
                    positive_inventory_sum=float(np.maximum(used,0).sum()),
                    negative_inventory_sum=float(np.maximum(-used,0).sum()),
                    holding_cost=float(np.maximum(used,0).sum()),
                    stockout_cost=float(9*np.maximum(-used,0).sum()),
                    total_cost=float(np.maximum(used,0).sum()+9*np.maximum(-used,0).sum()),
                    turnover=max(0,raw_turnover), turnover_raw=raw_turnover,
                    stockout_rate=float((used<0).sum()/len(inv)),
                    stockout_days=int((used<0).sum()),
                    inventory_length=len(inv), demand_length=len(demand),
                    billed_points=len(used), ave_demand=row.ave_demand,
                    vlt_num=int(str(row.vlt).split()[0])))
            lengths = df.test_inv.map(lambda s:len(numeric_list(s)))
            demands = df.test_demand.map(lambda s:len(numeric_list(s)))
            quality.append(dict(group=group,period=period,rows=len(df),
                inventory_length_min=int(lengths.min()),inventory_length_max=int(lengths.max()),
                equal_inventory_demand_length=int((lengths==demands).sum()),
                inventory_length_is_demand_plus_one=int((lengths==demands+1).sum())))
    panel = pd.DataFrame(output)
    for group in ['treatment','control']:
        a=panel.query('group == @group and period == "pre"').pair_id
        b=panel.query('group == @group and period == "post"').pair_id
        assert set(a)==set(b)
    return panel, pd.DataFrame(quality)


def ols(y, X, names, covariance='classical'):
    """OLS + classical 或 HC1 标准误，避免依赖 statsmodels。

    HC1 用于变化值回归；p值采用残差自由度的t分布。
    """
    y, X = np.asarray(y,float), np.asarray(X,float)
    n,k=X.shape
    assert np.linalg.matrix_rank(X)==k
    beta=np.linalg.lstsq(X,y,rcond=None)[0]
    resid=y-X@beta
    bread=np.linalg.inv(X.T@X)
    if covariance=='classical':
        cov=bread*(resid@resid)/(n-k)
    else:
        meat=X.T@(X*resid[:,None]**2)
        cov=(n/(n-k))*bread@meat@bread
    se=np.sqrt(np.maximum(np.diag(cov),0))
    t=beta/se
    p=2*stats.t.sf(abs(t),n-k)
    crit=stats.t.ppf(.975,n-k)
    return [dict(term=name,coefficient=beta[j],std_error=se[j],t_value=t[j],
                 p_value=p[j],ci_low=beta[j]-crit*se[j],ci_high=beta[j]+crit*se[j],
                 n=n,df_resid=n-k,covariance=covariance)
            for j,name in enumerate(names)]


def field_analysis(panel, results):
    variants=[]
    for version,h,b in [('original_h1_b9',1,9),('paper_cost_fixed_paths_h12_b88',12,88)]:
        q=panel.copy()
        q['holding_cost']=h*q.positive_inventory_sum
        q['stockout_cost']=b*q.negative_inventory_sum
        q['total_cost']=q.holding_cost+q.stockout_cost
        q['version']=version
        variants.append(q)
    allrows=pd.concat(variants,ignore_index=True)
    means=allrows.groupby(['version','group','period'],sort=False)[METRICS].mean().reset_index()
    tests=[];regs=[];did=[]
    for version,q in allrows.groupby('version',sort=False):
        post=q[q.period=='post']
        treatment=post[post.group=='treatment'].sort_values('pair_id')
        control=post[post.group=='control'].sort_values('pair_id')
        ordered=pd.concat([treatment,control])
        indicator=np.r_[np.ones(len(treatment)),np.zeros(len(control))]
        base=np.column_stack([indicator,ordered.vlt_num,ordered.ave_demand])
        for metric in METRICS:
            tarr,carr=treatment[metric].to_numpy(),control[metric].to_numpy()
            for equal_var in [True,False]:
                test=stats.ttest_ind(tarr,carr,equal_var=equal_var)
                tests.append(dict(version=version,metric=metric,
                    test='pooled_t_original' if equal_var else 'welch_t',
                    treatment_mean=tarr.mean(),control_mean=carr.mean(),
                    difference=tarr.mean()-carr.mean(),
                    relative_difference=(tarr.mean()-carr.mean())/carr.mean(),
                    t_value=test.statistic,p_value=test.pvalue))
            for intercept in [False,True]:
                X=np.column_stack([np.ones(len(ordered)),base]) if intercept else base
                names=['intercept','is_e2e','vlt','demand'] if intercept else ['is_e2e','vlt','demand']
                for result in ols(ordered[metric],X,names):
                    regs.append(dict(version=version,metric=metric,
                        specification='paper_eq11_intercept' if intercept else 'notebook_no_intercept',
                        **result))

            # 原代码DiD：两组按行相减，比较post差异与pre差异；周转采用混合口径。
            preT=q[(q.group=='treatment')&(q.period=='pre')].sort_values('pair_id')
            preC=q[(q.group=='control')&(q.period=='pre')].sort_values('pair_id')
            original_c=control.turnover_raw.to_numpy() if metric=='turnover' else carr
            postdiff=tarr-original_c
            prediff=preT[metric].to_numpy()-preC[metric].to_numpy()
            test=stats.ttest_ind(postdiff,prediff)
            did.append(dict(version=version,metric=metric,
                specification='original_notebook_diff_test',
                estimate=postdiff.mean()-prediff.mean(),
                std_error=np.nan,t_value=test.statistic,p_value=test.pvalue,
                pre_treatment=preT[metric].mean(),post_treatment=tarr.mean(),
                pre_control=preC[metric].mean(),post_control=original_c.mean()))

            # 规范化对照：各组内按公开ID对应前后期，统一周转非负截断。
            # ID跨期对应的真实业务身份无法从脱敏数据独立验证，此处为明确假设。
            wide=q.pivot(index=['group','pair_id'],columns='period',values=metric)
            change=wide.post-wide.pre
            treat=(wide.index.get_level_values('group')=='treatment').astype(float)
            result=ols(change,np.column_stack([np.ones(len(change)),treat]),
                       ['intercept','is_e2e'],'HC1')[1]
            did.append(dict(version=version,metric=metric,
                specification='consistent_id_change_OLS_HC1',
                estimate=result['coefficient'],std_error=result['std_error'],
                t_value=result['t_value'],p_value=result['p_value'],
                pre_treatment=preT[metric].mean(),post_treatment=tarr.mean(),
                pre_control=preC[metric].mean(),post_control=carr.mean()))
    tests,regs,did=map(pd.DataFrame,[tests,regs,did])
    write_csv(allrows,results/'field_per_pair.csv')
    write_csv(means,results/'field_means.csv')
    write_csv(tests,results/'field_ttests.csv')
    write_csv(regs,results/'field_regressions.csv')
    write_csv(did,results/'field_did.csv')
    return means,tests,regs,did


def matching_analysis(data_dir, results):
    t=pd.read_csv(data_dir/'order_e2e_post_500.csv')
    c=pd.read_csv(data_dir/'control_demand_vlt.csv')
    tv=t[['ave_demand','vlt_num']].to_numpy(float)
    cv=c[['ave_demand','vlt_num']].to_numpy(float)
    X=np.vstack([tv,cv]); y=np.r_[np.ones(len(tv)),np.zeros(len(cv))]
    # 显式记录现代sklearn默认对应参数，结果可能与作者旧版本略有差异。
    logit=LogisticRegression(C=1.,solver='lbfgs',max_iter=100,random_state=0).fit(X,y)
    scores=logit.predict_proba(X)[:,1]; st,sc=scores[:len(t)],scores[len(t):]
    # 原 notebook 含组别列；固定差异不影响距离排名，但保留以重现算法。
    orig_t=np.column_stack([tv,np.ones(len(tv))])
    orig_c=np.column_stack([cv,np.zeros(len(cv))])
    nearest=NearestNeighbors(n_neighbors=1,algorithm='auto').fit(orig_c)
    distance,idx=nearest.kneighbors(orig_t);idx=idx.ravel()
    # 分析对照：真正按得分最近邻匹配，有放回，无caliper。
    propensity_nn=NearestNeighbors(n_neighbors=1,algorithm='auto').fit(sc[:,None])
    p_dist,p_idx=propensity_nn.kneighbors(st[:,None]);p_idx=p_idx.ravel()
    matches=[];balance=[];counts=[]
    for name,indices,dist in [('original_covariate_nn',idx,distance.ravel()),
                              ('propensity_score_nn',p_idx,p_dist.ravel())]:
        for i,j in enumerate(indices):
            matches.append(dict(method=name,treatment_row=i,
                treatment_pair_id=int(t.iloc[i].sku_dc_pair_index),control_candidate_row=int(j),
                control_candidate_id=int(c.iloc[j]['Unnamed: 0']),
                distance=dist[i],treatment_score=st[i],control_score=sc[j]))
        counts.append(dict(method=name,matched_rows=len(indices),
                           unique_control_rows=len(np.unique(indices)),replacement=True))
    for name,values in [('unmatched',cv),('original_covariate_nn',cv[idx]),
                         ('propensity_score_nn',cv[p_idx])]:
        for j,col in enumerate(['ave_demand','vlt_num']):
            # 使用匹配前合并标准差作为统一分母。
            denom=np.sqrt((np.var(tv[:,j],ddof=1)+np.var(cv[:,j],ddof=1))/2)
            balance.append(dict(method=name,covariate=col,treatment_mean=tv[:,j].mean(),
                control_mean=values[:,j].mean(),
                standardized_mean_difference=(tv[:,j].mean()-values[:,j].mean())/denom))
    write_csv(pd.DataFrame(matches),results/'matching_pairs.csv')
    write_csv(pd.DataFrame(balance),results/'matching_balance.csv')
    write_csv(pd.DataFrame(counts),results/'matching_counts.csv')
    write_csv(pd.DataFrame(dict(group=['treatment']*len(t)+['control']*len(c),
                               source_row=list(range(len(t)))+list(range(len(c))),
                               propensity_score=scores)),results/'propensity_scores.csv')
    return st,sc,idx,p_idx,pd.DataFrame(counts),pd.DataFrame(balance)


def theorem_validation():
    """200个小规模完全信息算例：定理1 vs 整段时域线性规划。
    自建测试，不使用公开CSV中语义待确认的 OPT_pred，不声称恢复原文标签。
    """
    from scipy.optimize import linprog
    rng=np.random.default_rng(20261019); rows=[]
    for case in range(200):
        T=12; arrivals=np.array([0,3,7]);M=len(arrivals)
        demand=rng.integers(0,8,T);initial=int(rng.integers(-10,40))
        h=int(rng.integers(1,10));b=int(rng.integers(1,15))
        objective=np.r_[np.zeros(M),np.repeat(h,T),np.repeat(b,T)]
        A=np.zeros((T,M+2*T))
        for t in range(T):
            A[t,:M]=arrivals<=t;A[t,M+t]=-1;A[t,M+T+t]=1
        solution=linprog(objective,A_eq=A,b_eq=np.cumsum(demand)-initial,
                         bounds=[(0,None)]*len(objective),method='highs')
        assert solution.success
        inventory=initial;cost=0
        for m,start in enumerate(arrivals):
            end=arrivals[m+1] if m+1<M else T
            cutoff=start+b*(end-start)//(h+b)
            order=max(int(demand[start:cutoff+1].sum())-inventory,0)
            inventory+=order
            for t in range(start,end):
                inventory-=int(demand[t]);cost+=h*max(inventory,0)+b*max(-inventory,0)
        rows.append(dict(case=case,h=h,b=b,initial_stock=initial,
                         theorem_cost=cost,lp_cost=solution.fun,gap=cost-solution.fun))
    result=pd.DataFrame(rows)
    assert result.gap.abs().max()<1e-7
    return result


def figures(summary, original, means, did, matching, figdir):
    plt.rcParams.update({'font.size':10,'axes.spines.top':False,'axes.spines.right':False,
                         'figure.dpi':140,'savefig.bbox':'tight'})
    fig,ax=plt.subplots(figsize=(10,5))
    x=np.arange(len(METHODS)); w=.37
    ax.bar(x-w/2,original.total_cost,w,label='Public subset: original code',color='#217c91')
    ax.bar(x+w/2,original.paper_total_cost,w,label='Paper: full data',color='#b2bbc4')
    ax.set_xticks(x,METHODS);ax.set_ylabel('Average cost (different sample scopes)')
    ax.set_title('Offline evaluation: cached predictions, no model retraining')
    ax.legend();fig.tight_layout();fig.savefig(figdir/'01_offline_comparison.png');plt.close(fig)
    pivot=summary.pivot(index='method',columns='profile',values='total_cost').loc[METHODS,list(PROFILES)]
    fig,ax=plt.subplots(figsize=(11,5.3))
    colors=['#217c91','#6d9f65','#de9a42','#8b7caa','#c45c4e']
    for j,profile in enumerate(PROFILES):
        ax.bar(x+(j-2)*.15,pivot[profile],.15,label=profile,color=colors[j])
    ax.set_xticks(x,METHODS);ax.set_ylabel('Average cost under retained billing windows')
    ax.set_title('Implementation diagnostics: fixed cached predictions (not retrained)')
    ax.legend(fontsize=8,ncol=2);fig.tight_layout();fig.savefig(figdir/'02_offline_diagnostics.png');plt.close(fig)
    fig,axes=plt.subplots(1,2,figsize=(10,4.2))
    q=means[means.version=='original_h1_b9']
    for ax,metric in zip(axes,['total_cost','turnover']):
        for group,color in [('treatment','#217c91'),('control','#c45c4e')]:
            values=q[q.group==group].set_index('period').loc[['pre','post'],metric]
            ax.plot([0,1],values,marker='o',lw=2.5,label=group,color=color)
        ax.set_xticks([0,1],['Pre','Post']);ax.set_title(metric);ax.legend()
    fig.suptitle('Field subset: 500 pairs per group; original metric windows; h=1, b=9')
    fig.tight_layout();fig.savefig(figdir/'03_field_pre_post.png');plt.close(fig)
    st,sc,idx,pidx,counts,balance=matching
    fig,axes=plt.subplots(1,3,figsize=(12,3.7),sharex=True)
    for ax,title,control in zip(axes,['Before matching','Original covariate NN','Propensity-score NN'],
                               [sc,sc[idx],sc[pidx]]):
        bins=np.linspace(min(st.min(),control.min()),max(st.max(),control.max()),18)
        ax.hist(st,bins=bins,density=True,alpha=.55,label='Treatment',color='#217c91')
        ax.hist(control,bins=bins,density=True,alpha=.5,label='Control',color='#de9a42')
        ax.set_title(title);ax.set_xlabel('Propensity score');ax.legend(fontsize=8)
    axes[0].set_ylabel('Density');fig.tight_layout();fig.savefig(figdir/'04_matching.png');plt.close(fig)


def html_table(df):
    return df.to_html(index=False,border=0,float_format=lambda v:f'{v:.6g}',escape=True)


def make_report(root,summary,original,diag,means,tests,regs,did,quality,matching,checks):
    """自包含中文HTML：图像内嵌，无外链、无需服务器。"""
    def img(name):
        encoded=base64.b64encode((root/'figures'/name).read_bytes()).decode()
        return f'<img alt="{html.escape(name)}" src="data:image/png;base64,{encoded}">'
    original_field=means[means.version=='original_h1_b9'].drop(columns='version')
    ttests=tests[(tests.version=='original_h1_b9')&(tests.test=='pooled_t_original')]
    reg_e2e=regs[(regs.version=='original_h1_b9')&(regs.term=='is_e2e')]
    did_original=did[did.version=='original_h1_b9']
    cost_reweight=means[means.version=='paper_cost_fixed_paths_h12_b88'].drop(columns='version')
    smry=summary.pivot(index='method',columns='profile',values='total_cost').loc[METHODS,list(PROFILES)].reset_index()
    negatives=diag[diag.profile=='original'][['method','negative_applied_orders','index_fallbacks']]
    report='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><title>E2E库存论文第一阶段复现报告</title>
<style>body{font-family:system-ui,"Microsoft YaHei",sans-serif;max-width:1100px;margin:40px auto;padding:0 24px;color:#182733;line-height:1.8;background:#fff}h1{font-size:30px}h2{font-size:23px;margin-top:40px;border-bottom:1px solid #dbe3e8;padding-bottom:8px}h3{font-size:18px;margin-top:26px}table{border-collapse:collapse;width:100%;font-size:13px;margin:16px 0;display:block;overflow:auto}th,td{padding:9px 12px;border:1px solid #dbe3e8;text-align:right;white-space:nowrap}th{background:#eaf1f5;color:#142633}td:first-child,th:first-child{text-align:left}tr:nth-child(even){background:#f8fafb}img{width:100%;height:auto;margin:16px 0}code{background:#f0f3f5;padding:2px 5px}pre{white-space:pre-wrap;background:#f0f3f5;padding:16px}p,li{font-size:16px}.muted{color:#526474;font-size:14px}@media print{body{max-width:none;margin:0}h2{break-after:avoid}img,table{break-inside:avoid}}</style><body>
<p class="muted">Qi et al. · Management Science 69(2), 759–773 · DOI 10.1287/mnsc.2022.4564</p>
<h1>E2E库存论文第一阶段复现报告</h1>
<p><strong>本报告完成公开子样本的评价复算、统计分析与实现差异诊断。没有训练E2E或LightGBM模型，也没有恢复全文全量实验。</strong>原始输入来自用户提供的 replication_package_MS-FTBDA-20-01585.zip；论文数值仅用于对照。</p>
<p>离线文件共3,000条记录、2,607个不同SKU字段值；现场数据每组每期500条；候选对照55,333条。各组原始观察长度不一致。本报告保留源数据，不推断缺失日期或私有业务规则。</p>
<p><strong>主要发现：</strong>原代码下E2E_RNN总成本为3036.76，低于其余可执行比较方法；现场子样本实验后总成本为E2E组884.09、对照组1985.15。但仅将补货截断为非负，E2E总成本为2671.75，GBM为2564.07，BM2为2641.03，排序发生变化。这是评价规则敏感性的证据，不能据此宣称重新训练后的E2E优劣。</p>
<h2>1 运行方式与文件说明</h2><pre>python -m pip install -r requirements.txt
python run_replication.py</pre>
<p>代码：run_replication.py。交互入口：replication_walkthrough.ipynb。原始数据：data/。原始笔记本：original_notebooks/。结果表：results/。图：figures/。运行会重建结果，不会改变输入数据。</p>
<p>OLS用NumPy最小二乘和SciPy t分布计算；与普通无权重OLS公式一致，不依赖statsmodels。详细协方差、自由度、系数和p值保存在CSV。所有数值为公开样本计算值，不能替代论文全量结果。</p>
<h2>2 离线评价原代码复算</h2>
<p>严格重现原笔记本的预测转订单、取整、库存更新、分组及计费窗口。E2E、GBM、OPT均读取缓存预测列；BM1/BM2/Normal/Gamma按原笔记本计算。以下七种方法总成本均通过与原笔记本保存输出的数值比对。</p>'''
    report+=html_table(original.drop(columns='profile'))+img('01_offline_comparison.png')
    report+='''<p>OPT列仅表示公开文件中的OPT_pred经过原评价器计算后的结果。修正评价规则后不能继续保证该缓存决策是新环境的最优解。全文图2与本表使用不同样本，且代码与论文存在实现差异，不能将数值差异直接解释为论文结果错误。</p>
<h2>3 离线公式修正与假设性诊断</h2>
<p><strong>normal_eq7_only</strong>：只把Normal的z值从1.64改为Φ⁻¹(0.9)，并把方差项σ_D²σ_L改为论文的μ_D²σ_L²，保留原代码整型转换和其他规则。这是明确的公式一致性修正。</p>
<p><strong>nonnegative_only</strong>：仅将实际补货截断为非负；<strong>full_backlog_only</strong>：仅保留到货前欠货；<strong>combined_diagnostic</strong>：合并上述两个变更与Normal公式修正。后三项属于实现敏感性，依赖缓存预测可解释为目标库存水平这一未确认假设，不能称为作者模型的纠正后性能。</p>
<p>所有诊断均使用固定缓存预测，不重新训练，不改变原计费窗口，也不解决未来库存特征、真实提前期及多订单路径缺失问题。</p>'''
    report+=html_table(smry)+img('02_offline_diagnostics.png')
    report+='<h3>原代码负补货与索引回退</h3>'+html_table(negatives)
    report+='''<p>README将预测列称为订货量，但模拟代码再次扣除库存；若预测值实际已是订货量，该处理会重复扣库存。其真实语义需作者确认。原代码在到货前库存为负时清除欠货，并只对截取后的inv2序列计费。BM1/BM2使用预测序列均值乘天数，未完整实现论文描述的分位数/逐日优化步骤。</p>
<h2>4 现场实验原代码指标与检验</h2>
<p>保留原代码h=1、b=9，累计库存序列前T−1个点，缺货比例除以T，周转指标取max(平均净库存/平均需求,0)。周转指标按论文定义更接近周转天数。累计成本未按不同观察长度标准化。</p>'''
    report+=html_table(original_field)+html_table(ttests[['metric','treatment_mean','control_mean','difference','relative_difference','t_value','p_value']])+img('03_field_pre_post.png')
    report+='<h3>观察窗口核查</h3>'+html_table(quality)
    report+='''<p>库存序列与需求序列有的等长、有的差1，且个别库存序列只有1个点。缺少逐点日期和边界定义，无法可靠决定应删首点还是末点，因此本报告不把统一窗口修正伪装成已知答案。</p>
<h2>5 回归与DiD</h2>
<p>notebook_no_intercept按原代码估计；paper_eq11_intercept补入论文公式（11）的截距，其他变量和样本保持一致。两者均为经典OLS标准误。这里的差异是模型设定差异，不是抽样变化。</p>'''
    report+=html_table(reg_e2e[['metric','specification','coefficient','std_error','p_value']])
    report+='''<p>original_notebook_diff_test保留源代码对post差值与pre差值的独立样本t检验，并保留周转指标中实验后对照组未截断的混合口径。consistent_id_change_OLS_HC1先按组别与公开pair_id对应前后期，再对变化值回归处理组指示变量，统一周转非负截断并用HC1标准误。后者依赖公开ID确实代表同一跨期业务单元的假设；脱敏资料不足以独立验证这一身份对应。</p>'''
    report+=html_table(did_original[['metric','specification','estimate','std_error','p_value']])
    report+='''<p>变化值回归仍依赖平行趋势等识别条件；只有汇总前后期，不能据此完成多期平行趋势检验。也不能恢复SKU或配送中心层面的聚类结构。代码未将这类缺失检验补成已完成。</p>
<h2>6 按论文现场成本参数重算固定路径</h2>
<p>论文现场实验写h=12、b=88，公开代码使用h=1、b=9。下表仅在固定历史库存轨迹上重新计价。没有重新决策或重新训练，因此不代表更换成本参数后算法会产生的实际经营结果。</p>'''
    report+=html_table(cost_reweight)
    report+='''<h2>7 匹配过程</h2>
<p>原笔记本先估计倾向得分，但实际对未标准化的需求、提前期及组别列做最近邻匹配，允许有放回。组别列对所有候选对产生同一固定差异，不改变排名。对照版本真正按倾向得分做最近邻匹配，同样有放回且未设caliper；它只是明确指定的新分析，并非恢复作者私有匹配流程。</p>'''
    report+=html_table(matching[4])+html_table(matching[5])+img('04_matching.png')
    report+='''<p>图中分布重合不等于消除全部混杂。55,333个候选对照仅公开协变量，不能为新匹配的候选样本恢复库存结果，因此新匹配不接入现场成本/DiD分析。500条现有对照结果也不能仅凭重新编号与候选表建立真实身份连接。</p>
<h2>8 验证与复现边界</h2>
<p>额外构造200个完全信息小算例，将定理1标签策略与完整时域线性规划最优值比较，最大成本差为0。这是公式算法验证，不是公开OPT_pred标签再生成。</p>'''
    report+=html_table(pd.DataFrame(checks))
    report+='''<p>未完成且不能凭现有包完成：E2E/MQRNN/LightGBM从头训练、原模型重新推理、全量论文数值、附录B重新训练的敏感性实验、原始全量标签重建、线上部署。缺少训练源码、权重、完整可连接训练数据、损失及超参数配置。</p>
<p class="muted">来源定位：E2E_Section4 cell 4/6/8/11/14；Field_experiments_summary cell 5/7/10/23–27/29/30/32/35/37–46；Propensity_score_matching cell 11/13/14。源笔记本均随包保留。论文对照来自用户提供的正式PDF：第3–5节及附录A/B。</p></body></html>'''
    (root/'replication_report.html').write_text(report,encoding='utf-8')


def main(root):
    root=Path(root).resolve();data=root/'data';results=root/'results';figdir=root/'figures'
    results.mkdir(exist_ok=True);figdir.mkdir(exist_ok=True)
    hashes={p.name:hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(data.glob('*.csv'))}
    raw=load_offline(data)
    summary,original,diag,checks=offline_analysis(raw,results)
    panel,quality=load_field(data)
    write_csv(quality,results/'field_window_audit.csv')
    means,tests,regs,did=field_analysis(panel,results)
    matching=matching_analysis(data,results)
    validation=theorem_validation();write_csv(validation,results/'theorem_validation.csv')
    checks.append(dict(check='theorem_vs_LP_max_abs_gap_200_cases',expected=0,
                       actual=validation.gap.abs().max(),passed=True))
    original_means=means[means.version=='original_h1_b9'].set_index(['group','period'])
    expected=[('treatment','post',884.09),('control','post',1985.148),
              ('treatment','pre',1482.262),('control','pre',979.59)]
    for group,period,value in expected:
        actual=original_means.loc[(group,period),'total_cost']
        passed=bool(np.isclose(actual,value,atol=1e-8,rtol=0));assert passed
        checks.append(dict(check=f'field_original_total_{group}_{period}',
                           expected=value,actual=actual,passed=passed))
    # 独立核对无截距OLS的预存结果，确保替代统计库没有改变模型。
    for metric,expected_coef in [('holding_cost',-220.529018),('total_cost',-955.768361),
                                 ('turnover',.345794)]:
        row=regs[(regs.version=='original_h1_b9')&(regs.specification=='notebook_no_intercept')
                 &(regs.metric==metric)&(regs.term=='is_e2e')].iloc[0]
        passed=bool(np.isclose(row.coefficient,expected_coef,atol=2e-6,rtol=0));assert passed
        checks.append(dict(check='cached_OLS_'+metric,expected=expected_coef,
                           actual=row.coefficient,passed=passed))
    write_csv(pd.DataFrame(checks),results/'validation_checks.csv')
    figures(summary,original,means,did,matching,figdir)
    make_report(root,summary,original,diag,means,tests,regs,did,quality,matching,checks)
    packages=['numpy','pandas','scipy','scikit-learn','matplotlib']
    versions={p:importlib.metadata.version(p) for p in packages}
    manifest={'scope':'public subset evaluation; no model training',
        'python':platform.python_version(),'platform':platform.platform(),
        'packages':versions,'data_sha256':hashes,'profiles':PROFILES,
        'matching':{'replacement':True,'caliper':None,'logit_C':1.,
                    'solver':'lbfgs','max_iter':100,'random_state':0},
        'validated_checks':len(checks)}
    (results/'run_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    (root/'requirements.txt').write_text('\n'.join(f'{p}=={v}' for p,v in versions.items())+'\n')
    print('\nSUCCESS: outputs in',root)
    print(original[['method','total_cost']].to_string(index=False))
    return manifest


if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root',type=Path,default=Path(__file__).resolve().parent)
    args=parser.parse_args();main(args.root)
