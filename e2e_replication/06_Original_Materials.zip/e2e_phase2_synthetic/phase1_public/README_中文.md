# E2E库存论文第一阶段复现包

本包复算 Qi et al. (2023), A Practical End-to-End Inventory Management Model with Deep Learning 的公开子样本评价。不是从头训练模型，也不是全文全量数据的精确复制。

## 先看哪里

1. 打开 replication_report.html 查看自包含中文报告；不需要联网或启动服务。
2. 查看 results/offline_original_vs_paper.csv 与 results/field_means.csv 获取主要数值。
3. 阅读 run_replication.py 的中文注释，或在 Jupyter 中打开 replication_walkthrough.ipynb。

## 运行

本次已验证环境为 Python 3.12.14，建议使用 Python 3.12。requirements.txt 记录本次实际验证的依赖版本。

    python -m venv .venv
    # Windows: .venv\Scripts\activate
    # macOS/Linux: source .venv/bin/activate
    python -m pip install -r requirements.txt
    python run_replication.py

Jupyter 是可选阅读方式，主程序不需要 Jupyter、PyTorch 或 statsmodels。若依赖已经具备，可直接运行最后一条命令。程序按自身所在目录定位数据，运行后覆盖本包生成结果，不改动 data/ 中的输入。

## 完成内容

- 重现原公开笔记本的离线七种方法成本。
- 单独修正Normal公式，并对非负补货、全欠货更新做固定预测值的敏感性诊断。
- 重算四个现场样本的持有、欠货、总成本、周转指标、缺货比例。
- 重算原始等方差t检验，同时提供Welch检验。
- 重算无截距OLS，并与补入论文截距后的OLS比较。
- 重算原代码DiD，并提供统一指标、按公开ID对应前后期的变化值回归及HC1标准误。
- 在固定库存路径上以论文现场参数h=12,b=88重新计价。
- 重现原协变量最近邻匹配，并与真正按倾向得分最近邻的分析对照。
- 用200个自建算例核验定理1与完整时域线性规划的一致性。

## 结果文件

| 文件 | 内容 |
|---|---|
| offline_original_vs_paper.csv | 原代码子样本结果与论文全量图2数值对照 |
| offline_profiles.csv | 五种计算口径下的七种方法平均成本 |
| offline_per_sku.csv | 每种口径、每个SKU字段、每种方法的成本及诊断 |
| offline_diagnostics.csv | 负补货、索引回退、计费窗口长度汇总 |
| field_means.csv | 原成本参数及论文参数固定路径计价的分组均值 |
| field_per_pair.csv | 各组、各期、各个公开ID的指标明细 |
| field_ttests.csv | 等方差t检验与Welch检验，含相对差异 |
| field_regressions.csv | 全部OLS系数、标准误、t值、p值、置信区间 |
| field_did.csv | 原代码DiD及统一口径变化值回归对照 |
| field_window_audit.csv | 库存/需求长度及观察窗口核查 |
| matching_pairs.csv | 两种匹配方法选择的候选对照行；不能当作现有对照结果表的身份映射 |
| matching_balance.csv | 需求、提前期匹配前后标准化均值差，统一使用匹配前分母 |
| matching_counts.csv | 匹配数量、不同对照数量、有放回标识 |
| propensity_scores.csv | 全部候选样本的估计倾向得分 |
| theorem_validation.csv | 200个自建算例的定理成本与LP成本 |
| validation_checks.csv | 原笔记本数值、OLS数值与公式验证核对 |
| run_manifest.json | 实际Python/依赖版本、输入SHA256及分析设定 |

所有CSV采用UTF-8 BOM编码，便于Excel打开。字段名保持英文以便程序处理；NaN表示该统计量没有报告，不代表0。relative_difference为小数，例如-0.20表示下降20%。p_value保存科学计数数值，报告中的小数显示不是精度截断后的检验。

## 五种离线口径

- original：保留作者公开笔记本的规则，包括其负补货与到货时清除欠货等行为，仅用于忠实复算。
- normal_eq7_only：仅把Normal的z值及提前期方差项改为论文公式（7）；仍保留整型转换。
- nonnegative_only：仅将实际补货截断为非负。
- full_backlog_only：仅在到货时保留前期负库存。
- combined_diagnostic：合并以上变更。

后三种是诊断性敏感性，不是已认证的正确仿真环境。所有场景均使用缓存预测、原计费窗口与原提前期列；缓存OPT列在改变环境后不再具有最优基准保证。README称预测为订货量，原代码却再次扣库存；该语义未解决，不能据此认定哪种修改是作者真实策略。

## 现场统计的解释边界

- 原代码h=1,b=9，与论文现场h=12,b=88不同；论文参数版本只重新计价固定历史路径。
- 原代码计费使用inv[:-1]，缺货比例分母为len(inv)。各样本时间窗口不同且缺少逐点日期，本包不猜测如何统一。
- OLS经典标准误按通常OLS公式计算；原代码未加截距，论文公式有截距，两个结果并列保留。
- 原DiD的实验后对照组周转使用未截断值，其他相关环节采用非负截断；对照分析统一非负截断。
- 变化值回归以group+pair_id作为跨期对应键。文件内唯一性和前后集合可验证，脱敏ID的真实业务连续性无法独立验证。HC1标准误不能代替缺失的SKU/DC聚类信息。
- 两期数据不能检验多期平行趋势；匹配也不保证消除未观察混杂。
- 新匹配候选只有协变量，没有完整结果，不能接入成本或DiD重新估计。

## 原始来源与保留材料

data/内CSV来自用户上传的replication_package_MS-FTBDA-20-01585.zip；original_notebooks/保留原作者的三份分析笔记本及README，未修改。原笔记本的预存输出可能来自旧运行，主报告以本次重新计算为准。

本包新增代码、图、报告由本次复现整理；源材料继续受原作者/提供方相应权利约束。本包没有赋予源数据新的对外再分发许可。

## 未包含的工作

没有完整训练集、训练源码、模型权重、全部特征与损失配置，故未训练E2E、MQRNN或LightGBM，未重新做附录B训练敏感性，也未重新开展线上实验。销售、库存、提前期的极小示例不能直接拼接为原始训练集。
