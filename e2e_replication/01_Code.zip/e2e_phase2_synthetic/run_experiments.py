"""合成数据的方法重建，非京东原始数据恢复。python run_experiments.py

真实训练PyTorch LSTM + 多期分位数解码器 + VLT MLP + E2E决策头，另训PTO与LightGBM。
所有缺失设定均在README披露，默认结果不要求E2E胜出。
"""
from __future__ import annotations
import os
os.environ.setdefault('OMP_NUM_THREADS','1')
os.environ.setdefault('MKL_NUM_THREADS','1')
import argparse, copy, hashlib, importlib.metadata, json, random, time
from dataclasses import dataclass, asdict
from pathlib import Path
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import linprog
import torch
from torch import nn
from torch.nn import functional as F
from torch.utils.data import DataLoader,TensorDataset
import lightgbm as lgb

ROOT=Path(__file__).resolve().parent
HIST=28;HORIZON=14;R=7
QUANTILES=np.array([.1,.5,.6,.7,.8,.9,.95],dtype=np.float32)
TRAIN_TIMES=np.arange(28,127,7)
VAL_START=154;VAL_END=182;TEST_START=210;TEST_END=240

@dataclass
class Config:
    hidden:int=50
    layers:int=2
    lr:float=.001
    dropout:float=.2
    batch:int=64
    epochs:int=35
    patience:int=8
    seed:int=11
    fraction:float=1.
    b:float=9.
    h:float=1.
    objective:str='e2e'
    optimizer:str='adam'
    lambda_d:float=.1
    lambda_l:float=.1

def save_csv(df,name):
    df.to_csv(ROOT/'results'/name,index=False,encoding='utf-8-sig')

def seed_everything(seed):
    random.seed(seed);np.random.seed(seed);torch.manual_seed(seed)
    torch.set_num_threads(1);torch.use_deterministic_algorithms(True)

def synthetic_data(n=160,seed=20261019):
    """bootstrap仅校准需求尺度，不补写任何真实记录。合成ID为SYN0000等。
    固定R=7，交货期1..6，保证不交叉、每个下单点无未到货订单；这是简化。
    """
    rng=np.random.default_rng(seed)
    public=pd.read_csv(ROOT/'data/public_calibration_only.csv').drop_duplicates('SKU')
    sample=public.iloc[rng.integers(0,len(public),n)]
    mu=np.clip(sample.demand_mean.to_numpy(),2.,60.)
    cv=np.clip(sample.demand_std.to_numpy()/np.maximum(sample.demand_mean.to_numpy(),1),.25,1.2)
    lead_mean=np.clip(sample.vendor_vlt_mean.to_numpy()/2,2.,5.)
    category=rng.integers(0,6,n);days=np.arange(260)
    promo=(rng.random((n,260))<.08).astype(float)
    demand=np.zeros((n,260),dtype=np.float32)
    ar=np.zeros(n)
    for t in days:
        ar=.65*ar+rng.normal(0,.08,n)
        weekday=1+.2*np.sin(2*np.pi*t/7+category*.3)
        mean=mu*weekday*(1+.6*promo[:,t])*np.exp(ar)
        dispersion=np.maximum(1/(cv**2),.5)
        demand[:,t]=rng.negative_binomial(dispersion,dispersion/(dispersion+mean))
    order_times=np.arange(0,260,7)
    leads=np.clip(np.rint(lead_mean[:,None]+.5*np.sin(order_times[None,:]/21)
                         +rng.normal(0,.8,(n,len(order_times)))),1,6).astype(int)
    reference=np.zeros_like(demand);initial=mu*(R+lead_mean)
    inv=initial.copy();incoming=np.zeros_like(demand)
    for t in days:
        reference[:,t]=inv
        if t%R==0:
            past=demand[:,max(0,t-HIST):t]
            mean=past.mean(1) if t else mu
            std=past.std(1) if t else mu*cv
            lm=leads[:,max(0,t//R-4):t//R].mean(1) if t else np.full(n,3.)
            target=mean*(R+lm)+1.28*std*np.sqrt(R+lm)
            a=np.maximum(np.rint(target-inv),0)
            arrival=t+leads[:,t//R];valid=arrival<260
            incoming[np.arange(n)[valid],arrival[valid]]+=a[valid]
        inv=inv+incoming[:,t]-demand[:,t]
    out=dict(demand=demand,promo=promo.astype(np.float32),category=category,
             leads=leads,reference=reference,mu=mu,cv=cv,lead_mean=lead_mean)
    np.savez_compressed(ROOT/'data/synthetic_inventory.npz',**out)
    save_csv(pd.DataFrame({'synthetic_id':[f'SYN{i:04d}' for i in range(n)],
                           'demand_scale':mu,'demand_cv':cv,'lead_scale':lead_mean}),
             'synthetic_calibration.csv')
    return out

def feature(d,ids,t,inventory,end):
    ids=np.asarray(ids);dem=d['demand'][ids,t-HIST:t]
    scale=np.maximum(dem.mean(1),1.).astype(np.float32)
    histdays=np.arange(t-HIST,t)
    hist=np.stack([dem/scale[:,None],d['promo'][ids,t-HIST:t],
                   np.broadcast_to(np.sin(2*np.pi*histdays/7),(len(ids),HIST)),
                   np.broadcast_to(np.cos(2*np.pi*histdays/7),(len(ids),HIST))],axis=-1)
    fdays=np.arange(t,t+HORIZON)
    future=np.stack([d['promo'][ids,t:t+HORIZON],
                      np.broadcast_to(np.sin(2*np.pi*fdays/7),(len(ids),HORIZON)),
                      np.broadcast_to(np.cos(2*np.pi*fdays/7),(len(ids),HORIZON))],axis=-1)
    basic=np.column_stack([np.eye(6)[d['category'][ids]],np.log1p(scale)/5])
    pastlead=d['leads'][ids,max(0,t//R-4):t//R]
    lf=np.column_stack([pastlead.mean(1)/7,pastlead.std(1)/7,
                        np.full(len(ids),np.sin(t/21)),np.full(len(ids),np.cos(t/21))])
    aux=np.column_stack([np.ones(len(ids)),np.minimum(end-t,HORIZON)/HORIZON*np.ones(len(ids)),
                         np.asarray(inventory)/(scale*R)])
    return [x.astype(np.float32) for x in [hist,future,basic,lf,aux]],scale

def labels(d,ids,t,inv,end,b,h):
    current=t+d['leads'][ids,t//R]
    nxt=np.minimum(t+R+d['leads'][ids,t//R+1],end)
    order=np.zeros(len(ids));total=np.zeros(len(ids))
    for j,i in enumerate(ids):
        if current[j]<end:
            cutoff=current[j]+int(np.floor(b*(nxt[j]-current[j])/(b+h)))
            order[j]=max(d['demand'][i,t:cutoff+1].sum()-inv[j],0)
        total[j]=d['demand'][i,t:nxt[j]].sum()
    return order,total

def samples(d,cfg,training=True):
    n=len(d['demand']);rng=np.random.default_rng(31415)
    selected=np.random.default_rng(17).permutation(n)[:max(1,int(n*cfg.fraction))] if training else np.arange(n)
    times=TRAIN_TIMES if training else np.arange(VAL_START,VAL_END,R)
    arrays=[[] for _ in range(9)]
    for t in times:
        inv=d['reference'][selected,t].copy()
        ids=selected.copy()
        if training:
            # 拓宽状态覆盖；随机状态仅用于监督标签，非真实历史库存。
            observed=d['demand'][selected,t-HIST:t].mean(1)
            randomized=observed*R*rng.uniform(-.5,2.2,len(ids))
            inv=np.r_[inv,randomized];ids=np.r_[ids,ids]
            end=t+HORIZON
            # 逐t统一截短窗口，帮助学习末期；只用过去需求构造特征。
            if (t//R)%5==0:end=t+int(rng.integers(3,HORIZON+1))
        else:end=VAL_END
        x,scale=feature(d,ids,t,inv,end)
        action,total=labels(d,ids,t,inv,end,cfg.b,cfg.h)
        y=[action/(scale*R),d['demand'][ids,t:t+HORIZON]/scale[:,None],
           d['leads'][ids,t//R]/7,total/(scale*R)]
        for j,v in enumerate(x+y):arrays[j].append(v)
    return [np.concatenate(a).astype(np.float32) for a in arrays]

class InventoryNet(nn.Module):
    """LSTM encoder + global/local multi-horizon quantile decoder。
    使用滑动下单窗口，不实现原MQ-RNN的全部forking-sequences训练。
    """
    def __init__(self,cfg):
        super().__init__();self.cfg=cfg
        self.encoder=nn.LSTM(11,cfg.hidden,batch_first=True)
        self.global_decoder=nn.Sequential(nn.Linear(cfg.hidden+7+HORIZON*3,100),nn.ReLU(),
                                          nn.Linear(100,(HORIZON+1)*8))
        self.local_decoder=nn.Sequential(nn.Linear(19,50),nn.ReLU(),nn.Linear(50,len(QUANTILES)))
        self.vlt1=nn.Linear(11,50);self.vlt2=nn.Linear(50,20);self.lead_output=nn.Linear(20,1)
        self.integration=nn.ModuleList()
        for k in range(cfg.layers):
            input_size=cfg.hidden+20+2 if k==0 else 100
            if k==cfg.layers-1:input_size+=1  # 库存只进入最后一个融合层
            self.integration.append(nn.Linear(input_size,100))
        self.action_output=nn.Linear(100,1)
        self.total_output=nn.Sequential(nn.Linear(cfg.hidden+20+2,100),nn.ReLU(),
                                         nn.Linear(100,len(QUANTILES)))
        self.dropout=nn.Dropout(cfg.dropout)
        for p in self.parameters():
            if p.ndim>=2:nn.init.normal_(p,0,.01)
            else:nn.init.zeros_(p)
        # 透明实现选择：LSTM遗忘门偏置1，以避免短窗口训练过早遗忘。
        with torch.no_grad():self.encoder.bias_ih_l0[cfg.hidden:2*cfg.hidden].fill_(1.)
    def forward(self,hist,future,basic,lead_features,aux):
        seq=torch.cat([hist,basic[:,None,:].expand(-1,HIST,-1)],dim=-1)
        _,(hidden,_)=self.encoder(seq);h=hidden[-1]
        context=self.global_decoder(torch.cat([h,basic,future.flatten(1)],dim=1)).reshape(-1,HORIZON+1,8)
        local=torch.cat([context[:,:HORIZON],context[:,-1:, :].expand(-1,HORIZON,-1),future],dim=-1)
        forecasts=F.softplus(self.local_decoder(local))
        v=F.relu(self.vlt1(torch.cat([lead_features,basic],dim=1)))
        v=self.dropout(v);v=F.relu(self.vlt2(v));v=self.dropout(v)
        lead=(1+5*torch.sigmoid(self.lead_output(v).squeeze(1)))/7
        merged=torch.cat([h,v,aux[:,:2]],dim=1)
        total=F.softplus(self.total_output(merged))
        z=merged
        for j,layer in enumerate(self.integration):
            if j==len(self.integration)-1:z=torch.cat([z,aux[:,2:3]],dim=1)
            z=self.dropout(F.relu(layer(z)))
        action=F.softplus(self.action_output(z).squeeze(1))
        return action,forecasts,lead,total

def pinball(pred,target):
    q=torch.as_tensor(QUANTILES,device=pred.device)
    err=target.unsqueeze(-1)-pred
    return torch.maximum(q*err,(q-1)*err).mean()

def objective(output,targets,cfg):
    a,dem,lead,total=output;ya,yd,yl,yt=targets
    primary=F.mse_loss(a,ya)
    demand_loss=pinball(dem,yd);lead_loss=F.mse_loss(lead,yl)
    if cfg.objective=='e2e':return primary+cfg.lambda_d*demand_loss+cfg.lambda_l*lead_loss,primary
    loss=demand_loss+lead_loss+pinball(total,yt)
    return loss,loss

def train(d,cfg,name):
    seed_everything(cfg.seed)
    xs=samples(d,cfg,True);vs=samples(d,cfg,False)
    tensors=[torch.from_numpy(x) for x in xs];valid=[torch.from_numpy(x) for x in vs]
    loader=DataLoader(TensorDataset(*tensors),batch_size=cfg.batch,shuffle=True,
                      generator=torch.Generator().manual_seed(cfg.seed))
    model=InventoryNet(cfg)
    if cfg.optimizer=='adam':optimizer=torch.optim.Adam(model.parameters(),lr=cfg.lr)
    else:optimizer=torch.optim.SGD(model.parameters(),lr=cfg.lr,momentum=.85)
    schedule=torch.optim.lr_scheduler.LambdaLR(optimizer,lambda e:1/(1+1e-4*e))
    best=np.inf;state=None;bad=0;history=[];start=time.perf_counter()
    for epoch in range(cfg.epochs):
        model.train();s=0;count=0
        for batch in loader:
            optimizer.zero_grad();out=model(*batch[:5]);loss,_=objective(out,batch[5:],cfg)
            assert torch.isfinite(loss)
            loss.backward();nn.utils.clip_grad_norm_(model.parameters(),5.)
            optimizer.step();s+=loss.item()*len(batch[0]);count+=len(batch[0])
        model.eval()
        with torch.no_grad():
            _,v=objective(model(*valid[:5]),valid[5:],cfg);val=float(v)
        history.append(dict(epoch=epoch+1,train_loss=s/count,validation_loss=val))
        if val<best-1e-6:best=val;state=copy.deepcopy(model.state_dict());bad=0
        else:bad+=1
        schedule.step()
        if bad>=cfg.patience:break
    elapsed=time.perf_counter()-start
    model.load_state_dict(state);model.eval()
    torch.save({'state_dict':state,'config':asdict(cfg),'validation_loss':best},ROOT/'models'/f'{name}.pt')
    save_csv(pd.DataFrame(history),f'training_{name}.csv')
    meta=dict(run=name,**asdict(cfg),training_samples=len(xs[0]),training_skus=max(1,int(len(d['demand'])*cfg.fraction)),
              epochs_run=len(history),training_seconds=elapsed,validation_loss=best)
    (ROOT/'models'/f'{name}.json').write_text(json.dumps(meta,indent=2),encoding='utf-8')
    print('TRAIN',name,'epochs',len(history),'seconds',round(elapsed,2),'val',round(best,5),flush=True)
    return model,meta

def flat_features(x):
    hist,fut,basic,lf,aux=x
    demand=hist[:,:,0]
    return np.column_stack([demand.mean(1),demand.std(1),demand[:,-7:].mean(1),
        demand[:,-1],demand[:,-7:].mean(1)-demand[:,:7].mean(1),fut[:,:,0].mean(1),basic,lf,aux])

def train_gbm(d,cfg):
    x=samples(d,cfg,True);v=samples(d,cfg,False)
    model=lgb.LGBMRegressor(n_estimators=500,num_leaves=15,learning_rate=.03,
        min_child_samples=20,random_state=cfg.seed,n_jobs=1,verbosity=-1,
        deterministic=True,force_col_wise=True)
    model.fit(flat_features(x[:5]),x[5],eval_set=[(flat_features(v[:5]),v[5])],
              callbacks=[lgb.early_stopping(30,verbose=False)])
    model.booster_.save_model(str(ROOT/'models/lightgbm.txt'))
    return model

def neural_predict(model,x):
    with torch.no_grad():return [a.cpu().numpy() for a in model(*[torch.from_numpy(v) for v in x])]

def rollout(d,method,b=9,h=1,model=None,gbm=None,q_index=5,start=TEST_START,end=TEST_END):
    """共同需求/实际交货期路径，决策只访问过去销量/已完成交货期与已知促销。
    真实提前期用于环境到货，不进入在线策略；OPT除外，它是明确标注的事后oracle。
    """
    n=len(d['demand']);ids=np.arange(n)
    init=np.rint(d['demand'][:,start-HIST:start].mean(1)*(R+3)*.75)
    inventory=init.copy();arrivals=np.zeros((n,end-start));paths=[];orders=[]
    for t in range(start,end):
        if t%R==0:
            x,scale=feature(d,ids,t,inventory,end)
            if method=='OPT':order,_=labels(d,ids,t,inventory,end,b,h)
            elif method=='E2E_RNN':order=neural_predict(model,x)[0]*scale*R
            elif method=='E2E_GBM':order=gbm.predict(flat_features(x))*scale*R
            elif method in ['BM1','BM2']:
                _,forecast,lead,total=neural_predict(model,x)
                if method=='BM1':order=total[:,q_index]*scale*R-inventory
                else:
                    lp=np.clip(np.rint(lead*7),1,6).astype(int)
                    order=np.zeros(n)
                    for i in ids:
                        vm=t+lp[i];vn=min(t+R+lp[i],end)
                        if vm>=end:continue
                        cutoff=vm+int(np.floor(b*(vn-vm)/(b+h)))
                        order[i]=(forecast[i,:cutoff-t+1,q_index].sum()*scale[i]-inventory[i])
            else:
                past=d['demand'][:,t-HIST:t];mu=past.mean(1);sd=past.std(1)
                leads=d['leads'][:,max(0,t//R-4):t//R];lm=leads.mean(1);ls=leads.std(1)
                protection=np.minimum(R+lm,end-t)
                if method=='Normal':target=mu*protection+stats.norm.ppf(b/(b+h))*np.sqrt(protection*sd**2+mu**2*ls**2)
                else:
                    theta=np.maximum(sd**2/np.maximum(mu,1e-6),1e-6)
                    k=np.maximum(mu/theta,1e-6)
                    target=stats.gamma.ppf(b/(b+h),a=k*protection,scale=theta)
                order=target-inventory
            order=np.maximum(np.rint(order),0)
            assert np.isfinite(order).all()
            when=t+d['leads'][:,t//R]
            for i in ids:
                orders.append(dict(synthetic_id=int(i),time=t,quantity=float(order[i]),arrival=int(when[i])))
                if when[i]<end:arrivals[i,when[i]-start]+=order[i]
        inventory=inventory+arrivals[:,t-start]-d['demand'][:,t]
        paths.append(inventory.copy())
    path=np.stack(paths,axis=1)
    holding=h*np.maximum(path,0).sum(1);shortage=b*np.maximum(-path,0).sum(1)
    detail=pd.DataFrame({'synthetic_id':ids,'holding_cost':holding,'stockout_cost':shortage,'total_cost':holding+shortage})
    result=dict(method=method,b=b,h=h,total_cost=float((holding+shortage).mean()),holding_cost=float(holding.mean()),
                stockout_cost=float(shortage.mean()),stockout_rate=float((path<0).mean()),days=end-start)
    return result,detail,path,pd.DataFrame(orders)

def validate_environment(d):
    checks=[]
    # oracle与完整LP比较，包含到货前固定成本；不依赖训练。
    res,_,_,_=rollout(d,'OPT')
    for i in range(min(12,len(d['demand']))):
        n=TEST_END-TEST_START;times=np.arange(TEST_START,TEST_END,R)
        arrivals=times+d['leads'][i,times//R];arrivals=arrivals[arrivals<TEST_END]-TEST_START;m=len(arrivals)
        init=np.rint(d['demand'][i,TEST_START-HIST:TEST_START].mean()*(R+3)*.75)
        # 初始库存与需求为整数；LP连续最优值与该整数oracle一致。
        A=np.zeros((n,m+2*n))
        for t in range(n):A[t,:m]=arrivals<=t;A[t,m+t]=-1;A[t,m+n+t]=1
        demand=d['demand'][i,TEST_START:TEST_END]
        lp=linprog(np.r_[np.zeros(m),np.ones(n),9*np.ones(n)],A_eq=A,
                   b_eq=np.cumsum(demand)-init,bounds=[(0,None)]*(m+2*n),method='highs')
        inv=init;cost=0.
        for t in range(n):
            if t in arrivals:
                j=int(np.where(arrivals==t)[0][0]);end=arrivals[j+1] if j+1<m else n
                cutoff=t+int(np.floor(.9*(end-t)));inv+=max(demand[t:cutoff+1].sum()-inv,0)
            inv-=demand[t];cost+=max(inv,0)+9*max(-inv,0)
        assert lp.success and abs(cost-lp.fun)<1e-5
        checks.append(dict(check=f'oracle_continuous_LP_{i}',gap=float(cost-lp.fun),passed=True))
    # 将未来实现值扰动；在当前时点构造特征必须不变。
    ids=np.arange(len(d['demand']));t=TEST_START;inv=np.ones(len(ids))
    original,_=feature(d,ids,t,inv,TEST_END)
    altered={k:v.copy() for k,v in d.items()}
    altered['demand'][:,t:]+=999;altered['leads'][:,t//R:]=6
    changed,_=feature(altered,ids,t,inv,TEST_END)
    assert all(np.array_equal(a,b) for a,b in zip(original,changed))
    checks.append(dict(check='no_future_demand_or_realized_lead_in_inputs',gap=0,passed=True))
    save_csv(pd.DataFrame(checks),'environment_checks.csv')

def select_quantile(d,model,method,b):
    costs=[]
    for j,q in enumerate(QUANTILES):
        r,*_=rollout(d,method,b=b,model=model,q_index=j,start=VAL_START,end=VAL_END)
        costs.append(r['total_cost'])
    best=int(np.argmin(costs))
    return best,[dict(method=method,b=b,quantile=float(q),validation_total_cost=c,selected=j==best)
                 for j,(q,c) in enumerate(zip(QUANTILES,costs))]

def main(args):
    for sub in ['data','models','results','figures']:(ROOT/sub).mkdir(exist_ok=True)
    d=synthetic_data(args.skus);validate_environment(d)
    cfg=Config(epochs=args.epochs,optimizer=args.optimizer)
    logs=[];summary=[]
    base,meta=train(d,cfg,'base');logs.append(meta)
    pto,pmeta=train(d,Config(epochs=args.epochs,objective='pto',optimizer=args.optimizer),'pto');logs.append(pmeta)
    gbm=train_gbm(d,cfg)
    qs=[];chosen={}
    for method in ['BM1','BM2']:
        q,detail=select_quantile(d,pto,method,9);qs+=detail;chosen[method]=q
    for method in ['OPT','E2E_RNN','BM1','BM2','Normal','Gamma','E2E_GBM']:
        model=base if method=='E2E_RNN' else pto
        r,detail,path,orders=rollout(d,method,model=model,gbm=gbm,q_index=chosen.get(method,5))
        summary.append(r);save_csv(detail,f'base_costs_{method}.csv');save_csv(orders,f'base_orders_{method}.csv')
        np.save(ROOT/'results'/f'base_inventory_{method}.npy',path)
    save_csv(pd.DataFrame(summary),'figure2_costs.csv');save_csv(pd.DataFrame(qs),'pto_quantile_selection.csv')
    # 保存固定前三个合成SKU预测；不挑选误差最小的样本。
    x,scale=feature(d,np.arange(3),TEST_START,d['reference'][:3,TEST_START],TEST_END)
    _,forecasts,_,_=neural_predict(base,x)
    np.savez_compressed(ROOT/'results/forecast_examples.npz',history=d['demand'][:3,TEST_START-HIST:TEST_START],
        future=d['demand'][:3,TEST_START:TEST_START+HORIZON],quantiles=forecasts*scale[:,None,None],levels=QUANTILES)
    baseline=next(r for r in summary if r['method']=='E2E_RNN')
    oracle=next(r for r in summary if r['method']=='OPT')
    sensitivity=[]
    experiments=[]
    for k in [1,3,4]:experiments.append(('layers',k,dict(layers=k)))
    for k in [30,40,60]:experiments.append(('hidden',k,dict(hidden=k)))
    for k in [.0001,.01]:experiments.append(('learning_rate',k,dict(lr=k)))
    for k in [.2,.4,.6,.8]:experiments.append(('data_fraction',k,dict(fraction=k)))
    experiments.append(('seed',29,dict(seed=29)))
    for group,value,changes in experiments:
        config=Config(**{**asdict(cfg),**changes});name=f'{group}_{value}'
        model,info=train(d,config,name);logs.append(info)
        r,*_=rollout(d,'E2E_RNN',model=model)
        sensitivity.append(dict(group=group,value=value,run=name,**r,
                                oracle_cost=oracle['total_cost'],training_seconds=info['training_seconds'],
                                training_samples=info['training_samples'],training_skus=info['training_skus']))
        save_csv(pd.DataFrame(logs),'training_runs.csv');save_csv(pd.DataFrame(sensitivity),'sensitivity_partial.csv')
    for group,value in [('layers',2),('hidden',50),('learning_rate',.001),('data_fraction',1.),('seed',11)]:
        sensitivity.append(dict(group=group,value=value,run='base',**baseline,oracle_cost=oracle['total_cost'],
             training_seconds=meta['training_seconds'],training_samples=meta['training_samples'],training_skus=meta['training_skus']))
    save_csv(pd.DataFrame(sensitivity),'sensitivity.csv')
    ratio_results=[]
    for b in [5,7,9,12,15,18,23]:
        if b==9:model=base
        else:
            model,info=train(d,Config(**{**asdict(cfg),'b':b}),f'cost_ratio_{b}');logs.append(info)
        for method in ['OPT','E2E_RNN','Normal','Gamma']:
            r,*_=rollout(d,method,b=b,model=model);ratio_results.append(r)
        save_csv(pd.DataFrame(ratio_results),'cost_ratio.csv');save_csv(pd.DataFrame(logs),'training_runs.csv')
    # 参数敏感性使用真正不同初始化所得权重，而非随机造热图。
    for seed,name in [(11,'base'),(29,'seed_29')]:
        ck=torch.load(ROOT/'models'/f'{name}.pt',weights_only=False,map_location='cpu')
        np.save(ROOT/'results'/f'vlt_weights_seed_{seed}.npy',ck['state_dict']['vlt1.weight'].numpy())
    manifest=dict(scope='SYNTHETIC METHOD RECONSTRUCTION; NOT JD DATA RECOVERY',
        synthetic_skus=args.skus,train_times=TRAIN_TIMES.tolist(),validation=[VAL_START,VAL_END],
        test=[TEST_START,TEST_END],history=HIST,forecast_horizon=HORIZON,review_period=R,
        actual_lead_support=[1,6],quantiles=QUANTILES.tolist(),base=asdict(cfg),
        packages={p:importlib.metadata.version(p) for p in ['torch','lightgbm','numpy','pandas','scipy','scikit-learn','matplotlib','reportlab','Pillow']},
        calibration_sha256=hashlib.sha256((ROOT/'data/public_calibration_only.csv').read_bytes()).hexdigest(),
        training_runs=len(logs),global_seed=20261019,
        caveats=['No 132-feature reconstruction','No original training data or weights',
                 'No online field experiment','No order crossings or pending orders at decision epochs',
                 'Synthetic fully observed demand; no censoring','Adam default differs from paper-style SGD',
                 'Sliding windows instead of full forking-sequences','One seed per sweep; two initialization runs'])
    (ROOT/'results/manifest.json').write_text(json.dumps(manifest,indent=2),encoding='utf-8')
    (ROOT/'requirements.txt').write_text('--extra-index-url https://download.pytorch.org/whl/cpu\n'+
        '\n'.join(f'{k}=={v}' for k,v in manifest['packages'].items())+'\n')
    print('ALL EXPERIMENTS COMPLETE',flush=True)
    print(pd.DataFrame(summary).to_string(index=False),flush=True)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--skus',type=int,default=160)
    parser.add_argument('--epochs',type=int,default=35)
    parser.add_argument('--optimizer',choices=['adam','sgd'],default='adam')
    main(parser.parse_args())
