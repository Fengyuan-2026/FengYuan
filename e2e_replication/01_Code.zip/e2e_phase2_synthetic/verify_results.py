"""验证保存的实际结果；不选择或调整实验结论。"""
from pathlib import Path
import numpy as np
import pandas as pd
ROOT=Path(__file__).resolve().parent
def main():
    res=ROOT/'results';checks=pd.read_csv(res/'environment_checks.csv').to_dict('records')
    def check(name,passed,gap=0):checks.append(dict(check=name,gap=float(gap),passed=bool(passed)))
    costs=pd.read_csv(res/'figure2_costs.csv');opt=pd.read_csv(res/'base_costs_OPT.csv').total_cost.to_numpy()
    for _,r in costs.iterrows():
        det=pd.read_csv(res/f'base_costs_{r.method}.csv');orders=pd.read_csv(res/f'base_orders_{r.method}.csv')
        path=np.load(res/f'base_inventory_{r.method}.npy')
        check(f'{r.method}_cost_decomposition',np.isclose(r.total_cost,r.holding_cost+r.stockout_cost))
        check(f'{r.method}_detail_mean',np.isclose(r.total_cost,det.total_cost.mean()))
        check(f'{r.method}_path_cost',np.allclose(det.total_cost,(np.maximum(path,0)+9*np.maximum(-path,0)).sum(1)))
        gap=np.min(det.total_cost.to_numpy()-opt);check(f'{r.method}_above_oracle_per_sku',gap>=-1e-5,gap)
        check(f'{r.method}_nonnegative_integer_orders',((orders.quantity>=0)&(orders.quantity==np.rint(orders.quantity))).all())
        check(f'{r.method}_finite',np.isfinite(path).all() and np.isfinite(det.total_cost).all())
    sens=pd.read_csv(res/'sensitivity.csv');runs=pd.read_csv(res/'training_runs.csv')
    check('sensitivity_complete',len(sens)==18)
    check('neural_training_runs_complete',len(runs)==21)
    ratios=pd.read_csv(res/'cost_ratio.csv');check('cost_ratios_complete',len(ratios)==28)
    for b,g in ratios.groupby('b'):
        lower=g.loc[g.method=='OPT','total_cost'].iloc[0];check(f'ratio_{b}_above_oracle',(g.total_cost>=lower-1e-5).all())
    forecasts=np.load(res/'forecast_examples.npz')['quantiles']
    crossing=float((np.diff(forecasts,axis=-1)<0).mean())
    pd.DataFrame([{'scope':'fixed_first_3_examples_only','adjacent_quantile_crossing_fraction':crossing}]).to_csv(res/'forecast_diagnostics.csv',index=False)
    df=pd.DataFrame(checks);df.to_csv(res/'verification_summary.csv',index=False,encoding='utf-8-sig')
    print(df.loc[~df.passed].to_string(index=False));print(f'{df.passed.sum()}/{len(df)} checks passed; example crossing fraction={crossing:.4%}')
    assert df.passed.all(),'Verification failed; investigate before delivery.'
if __name__=='__main__':main()
