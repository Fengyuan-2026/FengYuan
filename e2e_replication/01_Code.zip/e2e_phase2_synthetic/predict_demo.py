"""加载已保存的合成数据模型，预测测试起点前3个SKU的订货量。"""
import json
import numpy as np
import torch
from run_experiments import ROOT,Config,InventoryNet,feature,neural_predict,R,TEST_START,TEST_END,HIST

if __name__=='__main__':
    saved=torch.load(ROOT/'models/base.pt',map_location='cpu',weights_only=True)
    model=InventoryNet(Config(**saved['config']));model.load_state_dict(saved['state_dict']);model.eval()
    d=dict(np.load(ROOT/'data/synthetic_inventory.npz'));ids=np.arange(3)
    initial=np.rint(d['demand'][ids,TEST_START-HIST:TEST_START].mean(1)*(R+3)*.75)
    x,scale=feature(d,ids,TEST_START,initial,TEST_END)
    order=np.maximum(np.rint(neural_predict(model,x)[0]*scale*R),0)
    rows=[{'synthetic_id':f'SYN{i:04d}','time':TEST_START,'initial_net_stock':float(initial[i]),'order':float(order[i])} for i in ids]
    print(json.dumps(rows,ensure_ascii=False,indent=2))
