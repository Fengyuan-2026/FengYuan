"""重算公开子集，并刷新第二阶段绘图使用的快照。"""
import shutil,subprocess,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
if __name__=='__main__':
    subprocess.run([sys.executable,str(ROOT/'phase1_public/run_replication.py')],check=True)
    for name in ['field_means','field_ttests','field_regressions','field_did','propensity_scores','matching_pairs']:
        shutil.copy2(ROOT/f'phase1_public/results/{name}.csv',ROOT/f'data/public_{name}.csv')
    print('Public subset snapshots refreshed. Run render_results.py to redraw.')
