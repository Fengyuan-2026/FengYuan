"""只读实际实验CSV/NPZ，生成论文式图表及中文报告；不训练、不调整结果。"""
from pathlib import Path
import base64, html, json
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, PageBreak, KeepTogether
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

ROOT=Path(__file__).resolve().parent
FIG=ROOT/'figures';RES=ROOT/'results'
BLUE='#234e87';STAMP='SYNTHETIC METHOD RECONSTRUCTION - NOT ORIGINAL JD RESULTS'
PUBLIC='PUBLIC RELEASED SUBSET - PHASE 1 RECOMPUTATION'
plt.rcParams.update({'font.family':'DejaVu Serif','font.size':10,'axes.titlesize':11,
    'axes.spines.top':False,'axes.spines.right':False,'svg.fonttype':'none','pdf.fonttype':42})
GALLERY=[]

def read(name):return pd.read_csv(RES/name)
def fmt(v):return f'{v:,.2f}'
def caption(fig,title,note='',public=False):
    fig.text(.04,.96,title,ha='left',va='top',color=BLUE,fontsize=12,weight='bold')
    fig.text(.04,.90,PUBLIC if public else STAMP,fontsize=8,color='#a34d1e')
    fig.text(.04,.025,note,fontsize=8,va='bottom',wrap=True)
def finish(fig,name,title):
    fig.savefig(FIG/f'{name}.png',dpi=210,facecolor='white')
    fig.savefig(FIG/f'{name}.svg',facecolor='white')
    plt.close(fig);GALLERY.append((name,title))
def table(ax,df,fontsize=9,bbox=None,widths=None):
    ax.axis('off')
    t=ax.table(cellText=df.astype(str).values,colLabels=list(df.columns),loc='center',cellLoc='center',bbox=bbox,colWidths=widths)
    t.auto_set_font_size(False);t.set_fontsize(fontsize);t.scale(1,1.9)
    for (r,c),cell in t.get_celld().items():
        cell.visible_edges='';cell.set_facecolor('white')
        if r==0:cell.visible_edges='TB';cell.set_linewidth(.9);cell.set_text_props(weight='bold')
        if r==len(df):cell.visible_edges='B';cell.set_linewidth(.9)
    return t
def table_page(df,name,title,note='',public=False,size=(11.8,4.0)):
    df.to_csv(RES/f'{name}.csv',index=False,encoding='utf-8-sig')
    fig=plt.figure(figsize=size);ax=fig.add_axes([.04,.15,.92,.66])
    widths=[.30,.26,.44] if name=='table_B1_hyperparameters' else None
    table(ax,df,8.5,bbox=[0,0,1,1],widths=widths);caption(fig,title,note,public);finish(fig,name,title)

def figures():
    costs=read('figure2_costs.csv');sens=read('sensitivity.csv');ratio=read('cost_ratio.csv')
    fig,ax=plt.subplots(figsize=(11.8,5.6));ax.set_axis_off();ax.set_xlim(0,10);ax.set_ylim(0,5)
    def box(x,y,w,h,label,color):
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.08',fc=color,ec='#555',lw=.8))
        ax.text(x+w/2,y+h/2,label,ha='center',va='center',fontsize=9)
    def arrow(a,b):ax.annotate('',xy=b,xytext=a,arrowprops={'arrowstyle':'->','color':'#555'})
    box(.2,3.3,2,.65,'28-day history +\nsynthetic SKU features','#d9e8f3')
    box(3,3.3,2,.65,'LSTM encoder\nhidden size 50','#b9d9cd')
    box(6,3.3,3,.65,'Global / local decoder\n14-day quantile forecasts','#f3bd8b')
    box(.2,1.8,2,.65,'Past realized lead times\n+ SKU features','#d9e8f3')
    box(3,1.8,2,.65,'VLT MLP 50 / 20\nlead-time head','#b9d9cd')
    box(6,1.8,3,.65,'Integration MLP 100 / 100\nstock enters final hidden layer','#b9d9cd')
    box(.2,.3,2,.65,'Known future promo /\ncalendar + time remaining','#d9e8f3')
    box(6,.3,3,.65,'Nonnegative order quantity\n(no second stock subtraction)','#f3bd8b')
    arrow((2.3,3.62),(2.9,3.62));arrow((5.1,3.62),(5.9,3.62))
    arrow((2.3,2.12),(2.9,2.12));arrow((5.1,2.12),(5.9,2.12))
    arrow((4.6,3.2),(6.6,2.55));arrow((2.3,.62),(5.9,1.9));arrow((7.5,1.7),(7.5,1.05))
    fig.subplots_adjust(top=.82,bottom=.12)
    caption(fig,'Figure 1. Implemented network structure (layout analogue)',
            'Chosen reconstruction: sliding review windows; additional PTO total-demand head is described in README.')
    finish(fig,'figure_1_network','图1｜实际实现的网络结构')

    ex=np.load(RES/'forecast_examples.npz');fig=plt.figure(figsize=(12,7))
    gs=fig.add_gridspec(3,2,left=.07,right=.97,bottom=.12,top=.83,width_ratios=[1.3,1],hspace=.55)
    for i in range(3):
        ax=fig.add_subplot(gs[i,0]);y=np.r_[ex['history'][i],ex['future'][i]];q=ex['quantiles'][i]
        ax.plot(np.arange(-28,14),y,color='#1f77b4',lw=1,label='Realized synthetic demand')
        ax.plot(np.arange(14),q[:,1],color='#e67d22',lw=1.2,label='Predicted median')
        ax.fill_between(np.arange(14),q[:,0],q[:,5],color='#f4b680',alpha=.35,label='Predicted q10-q90')
        ax.axvline(-.5,color='gray',ls='--',lw=.8);ax.set_title(f'SYN{i:04d}',loc='left',fontsize=9)
        ax.set_ylabel('Units');ax.set_xlabel('Days relative to forecast origin')
        if i==0:ax.legend(fontsize=6.5,loc='upper left',ncol=1)
    ax=fig.add_subplot(gs[:,1]);df=pd.DataFrame({'Algorithm':costs.method.str.replace('_',' '),
        'Total':costs.total_cost.map(fmt),'Holding':costs.holding_cost.map(fmt),'Stockout':costs.stockout_cost.map(fmt)})
    table(ax,df,8.5)
    caption(fig,'Figure 2. Demand forecasts and inventory costs',
        'Fixed first three synthetic SKUs; no example selection. Costs: mean per SKU over 30 days, h=1, b=9. OPT uses future information.')
    finish(fig,'figure_2_forecasts_costs','图2｜需求预测与七种方法成本')

    scores=pd.read_csv(ROOT/'data/public_propensity_scores.csv');pairs=pd.read_csv(ROOT/'data/public_matching_pairs.csv')
    pairs=pairs[pairs.method=='original_covariate_nn']
    fig,axs=plt.subplots(1,2,figsize=(11.8,4.6));fig.subplots_adjust(top=.8,bottom=.21,wspace=.25)
    tr=scores.loc[scores.group=='treatment','propensity_score'];ct=scores.loc[scores.group!='treatment','propensity_score']
    bins=np.linspace(min(scores.propensity_score.min(),pairs.control_score.min()),max(scores.propensity_score.max(),pairs.control_score.max()),28)
    for ax,a,b,title in [(axs[0],tr,ct,'Before matching'),(axs[1],pairs.treatment_score,pairs.control_score,'After matching')]:
        ax.hist(a,bins=bins,density=True,histtype='step',lw=1.5,label='Treatment');ax.hist(b,bins=bins,density=True,histtype='step',lw=1.5,label='Control')
        ax.set_title(title);ax.set_xlabel('Propensity score');ax.set_ylabel('Density');ax.legend(fontsize=8)
    caption(fig,'Figure 3. Propensity-score distributions (released subset)',
        'Original notebook matching: nearest neighbours in covariates, with replacement; score shown for diagnostics only.',True)
    finish(fig,'figure_3_public_matching','图3｜公开子集匹配诊断（非新增现场实验）')

    size=sens[sens.group=='data_fraction'].sort_values('value')
    fig,ax=plt.subplots(figsize=(8.5,5.4));fig.subplots_adjust(left=.14,right=.84,top=.81,bottom=.2)
    ax2=ax.twinx();a=ax.plot(size.value*100,size.total_cost,'o-',color='#008bc4',label='Average cost')
    b=ax2.plot(size.value*100,size.training_seconds,'s--',color='#009b2d',label='Training time')
    ax.set_xlabel('Percentage of training SKUs (%)');ax.set_ylabel('Average cost',color='#008bc4')
    ax2.set_ylabel('Training time (s)',color='#009b2d');ax.set_xticks([20,40,60,80,100]);ax.grid(alpha=.3)
    ax.legend(a+b,[x.get_label() for x in a+b],loc='best',fontsize=9)
    caption(fig,'Figure B.1. Sensitivity to training-data size','Nested training SKU sets; validation and test SKUs fixed. CPU timing is machine-dependent.')
    finish(fig,'figure_B1_data_size','图B.1｜数据量、成本与训练时间')

    fig,axs=plt.subplots(1,3,figsize=(12,4.5));fig.subplots_adjust(left=.07,right=.98,top=.8,bottom=.22,wspace=.35)
    for ax,metric,label in zip(axs,['total_cost','holding_cost','stockout_cost'],['Total cost','Holding cost','Stockout cost']):
        for method,color,marker in [('OPT','#0085b6','o'),('E2E_RNN','#ff851b','v'),('Normal','#009f28','*'),('Gamma','#ff343b','s')]:
            df=ratio[ratio.method==method].sort_values('b');ax.plot(df.b/df.h,df[metric],marker=marker,color=color,label=method.replace('_RNN',''),ms=4,lw=1.1)
        ax.set_xlabel('b/h');ax.set_ylabel(label);ax.legend(fontsize=7)
    caption(fig,'Figure B.2. Performance at different stockout / holding cost ratios',
        'Same synthetic paths at every ratio; E2E retrained with ratio-specific hindsight labels. Each sweep point uses one training seed.')
    finish(fig,'figure_B2_cost_ratio','图B.2｜缺货成本与持有成本比敏感性')

    weights=[np.load(RES/f'vlt_weights_seed_{s}.npy') for s in [11,29]];limit=max(abs(w).max() for w in weights)
    fig,axs=plt.subplots(1,2,figsize=(11.8,5));fig.subplots_adjust(left=.09,right=.88,bottom=.19,top=.78,wspace=.3)
    for ax,w,s in zip(axs,weights,[11,29]):
        im=ax.imshow(w,aspect='auto',cmap='jet',vmin=-limit,vmax=limit);ax.set_title(f'Seed {s}')
        ax.set_xlabel('Input feature index (11 reconstructed features)');ax.set_ylabel('VLT layer 1 neuron')
    cax=fig.add_axes([.91,.23,.018,.49]);fig.colorbar(im,cax=cax)
    caption(fig,'Figure B.3. Learned VLT-layer weights from two initializations',
        'Actual trained 50 x 11 matrices; shared symmetric colour scale. Two seeds do not establish robustness to all local minima.')
    finish(fig,'figure_B3_weights','图B.3｜两次实际训练的提前期网络权重')

    hp=pd.DataFrame([
        ['Demand LSTM','50','50; tested 30/40/50/60'],['VLT MLP','50 / 20','50 / 20 (no VLT-width sweep)'],
        ['Integration MLP','100 / 100','1-4 layers, width 100'],['Learning rate','0.001','0.0001 / 0.001 / 0.01'],
        ['Optimizer / momentum','Momentum = 0.85','Adam default; SGD option, momentum 0.85'],
        ['Learning-rate decay','0.0001','lr / (1 + 0.0001 x epoch)'],['Mini-batch','64','64'],
        ['Weight initialization','Normal(0, 0.01)','Normal(0, 0.01); LSTM forget bias = 1'],
        ['Activation / dropout','ReLU / 0.2','ReLU + Softplus outputs / 0.2'],
        ['Training / early stop','Not released in package','35 epochs maximum; patience 8'],
        ['Demand quantiles','Exact levels not released','0.1 / 0.5 / 0.6 / 0.7 / 0.8 / 0.9 / 0.95']],
        columns=['Hyperparameter','Paper / public package','This reconstruction'])
    table_page(hp,'table_B1_hyperparameters','Table B.1. Hyperparameters and disclosed reconstruction choices',
        'Paper settings do not specify a complete executable training recipe. This table records both retained and chosen settings.',size=(12,7))
    oracle=costs[costs.method=='OPT'].iloc[0]
    for group,num,title in [('layers',2,'Number of integration hidden layers'),('hidden',3,'Number of LSTM hidden units'),('learning_rate',4,'Learning rate'),('seed',6,'Two training initializations')]:
        df=sens[sens.group==group].sort_values('value')
        out={'Metric':['Total cost','Holding cost','Stockout cost']}
        out['OPT']=[fmt(oracle[x]) for x in ['total_cost','holding_cost','stockout_cost']]
        for _,r in df.iterrows():
            col=f'E2E ({r.value:g})';out[col]=[fmt(r.total_cost)+f' (+{(r.total_cost/oracle.total_cost-1)*100:.1f}%)',fmt(r.holding_cost),fmt(r.stockout_cost)]
        table_page(pd.DataFrame(out),f'table_B{num}',f'Table B.{num}. {title}',
            'Parentheses in total cost: percentage above OPT. Costs are per-SKU means over the same 30-day synthetic test paths.')
    out=pd.DataFrame({'Training %':(size.value*100).astype(int),'SKUs':size.training_skus.astype(int),
        'Training windows':size.training_samples.astype(int),'OPT cost':size.oracle_cost.map(fmt),
        'E2E cost':size.total_cost.map(fmt),'Training time (s)':size.training_seconds.map(fmt)})
    table_page(out,'table_B5','Table B.5. Training-data size, costs and computation time',
        'Two supervised inventory states per SKU / review. Timings exclude data generation, validation setup, plotting and other models.')

    metrics=['holding_cost','stockout_cost','total_cost','turnover','stockout_rate']
    cols=['Holding cost','Stockout cost','Total cost','Turnover','Stockout ratio']
    tt=pd.read_csv(ROOT/'data/public_field_ttests.csv');tt=tt[(tt.version=='original_h1_b9')&(tt.test=='pooled_t_original')].set_index('metric').loc[metrics]
    df=pd.DataFrame({'Statistic':['Treatment','Control','Difference','t-test p-value'],**{
        col:[fmt(r.treatment_mean),fmt(r.control_mean),f'{r.difference:.3f} ({r.relative_difference:.1%})',f'{r.p_value:.3g}'] for col,(_,r) in zip(cols,tt.iterrows())}})
    table_page(df,'table_2_public','Table 2. Treatment-control comparison in the released subset',
        'Notebook cost weights h=1, b=9; n=500 per group. These are recomputed subset statistics, not new field observations.',True)
    reg=pd.read_csv(ROOT/'data/public_field_regressions.csv');reg=reg[(reg.version=='original_h1_b9')&(reg.specification=='paper_eq11_intercept')&(reg.term=='is_e2e')].set_index('metric').loc[metrics]
    df=pd.DataFrame({'Statistic':['E2E coefficient','p-value'],**{col:[fmt(r.coefficient),f'{r.p_value:.3g}'] for col,(_,r) in zip(cols,reg.iterrows())}})
    table_page(df,'table_3_public','Table 3. E2E coefficients from regressions with an intercept',
        'Paper equation 11 specification; differs from the released notebook (no intercept). h=1, b=9; classical standard errors.',True)
    did=pd.read_csv(ROOT/'data/public_field_did.csv');did=did[(did.version=='original_h1_b9')&(did.specification=='consistent_id_change_OLS_HC1')].set_index('metric').loc[metrics]
    df=pd.DataFrame({'Statistic':['Treatment pre','Treatment post','Control pre','Control post','Difference-in-differences','p-value'],**{
        col:[fmt(r.pre_treatment),fmt(r.post_treatment),fmt(r.pre_control),fmt(r.post_control),fmt(r.estimate),f'{r.p_value:.3g}'] for col,(_,r) in zip(cols,did.iterrows())}})
    table_page(df,'table_4_public','Table 4. Difference-in-differences in the released subset',
        'Consistent metric definitions; SKU-aligned change regression, HC1 errors. h=1, b=9. This diagnostic does not identify new causal effects.',True,size=(12,4.8))

def report():
    cost=read('figure2_costs.csv');runs=read('training_runs.csv');sens=read('sensitivity.csv')
    base=cost.set_index('method').loc['E2E_RNN'];best=cost[cost.method!='OPT'].sort_values('total_cost').iloc[0]
    normal=cost.set_index('method').loc['Normal'];checks=read('verification_summary.csv')
    seed=sens[sens.group=='seed'].sort_values('value')
    sections=[
      ('交付性质与主要结果',[
       '本项目补建了可运行的合成数据训练与库存决策实验。原始京东训练数据、132项特征、原始权重和生产系统日志未公开，无法自动恢复。因此新增训练结果属于“合成数据方法重建”，不能作为原论文数值或现场效果的复现证明。公开子集的现场统计另行标注。',
       f'已完成 {len(runs)} 次神经网络训练，以及 LightGBM 基准。默认实验使用160个合成SKU、每个SKU 260天数据；测试窗口为第210—239天，共30天。OPT成本为 {cost.iloc[0].total_cost:,.2f}，E2E神经网络为 {base.total_cost:,.2f}，七种方法中可实施方法的最低成本为 {best.method} 的 {best.total_cost:,.2f}。',
       f'E2E神经网络相对Normal基准的成本变化为 {(base.total_cost/normal.total_cost-1)*100:+.2f}%，没有重现论文中E2E优于所有基准的排序。报告保留全部实际结果；不为接近论文数值而修改样本、选择曲线或替换结果。']),
      ('哪些已补全，哪些仍不能完成',[
       '已补全：合成需求、提前期、促销及库存轨迹；最优事后标签生成；LSTM多期分位数预测、VLT网络、E2E订货网络；独立训练的PTO基准与LightGBM；完整滚动库存模拟；隐藏层、隐状态维度、学习率、训练数据量、成本比和两次初始化实验；模型权重、逐轮日志、逐SKU成本、逐单订货和库存路径。',
       '仍不能完成：原始京东样本的精确训练结果、原始132特征的重建、被缺货截断的真实需求恢复、生产线上试验、新的现场因果效果，以及原文图表数值逐项一致。两次初始化不足以证明稳定性；各参数扫点仅使用一个训练种子。原文超参数表中的所有范围并未逐一穷举。']),
      ('合成数据的来源与边界',[
       '仅使用公开df_test中去重SKU的需求均值、需求标准差和供应商平均提前期，抽样校准数量级。需求均值截断至2—60，变异系数截断至0.25—1.2；提前期尺度先除以2再截断至2—5，这是人为的合成设定，不是估计出来的缺失真实值。合成ID为SYN0000等，不与原始SKU对应。',
       '需求使用负二项分布，叠加星期周期、6类合成SKU、提前已知的促销和AR(1)随机扰动。实际提前期取1—6天，订货周期固定7天，确保无交叉到货，且每次决策时没有在途订单。需求完全可观察、缺货完全积压。这些条件明显简化了真实业务。',
       '训练下单时点为28、35、…、126，每次加入参考库存和一个随机库存状态，共4800个训练样本。验证时间154—181，测试210—239；不同窗口之间有间隔，辅助预测标签不重叠到测试。训练和测试使用同一批SKU的不同时间段，衡量时间泛化，不是未见SKU泛化。']),
      ('核心公式与实际实现',[
       '每日净库存：I(t+1)=I(t)+当日到货量−当日需求。成本：C=Σ[h·max(I(t+1),0)+b·max(−I(t+1),0)]。所有30个测试日均计费，初始库存统一；订货量非负并取整。不存在到货时清空历史积压的处理。',
       '事后标签：对时刻t下单，到货时刻v=t+L(t)，下一到货边界w=min(t+R+L(t+R),T)，令k=v+floor[b(w−v)/(b+h)]，a*=max(Σ从t到k的需求−I(t),0)。若v≥T，标签为0。该简化环境下无在途订单；OPT使用未来实现值，只作为不可实施的下界。',
       '网络：需求历史28天输入LSTM（默认50隐单元），全局/局部解码器给出14天、7个分位数的需求预测；提前期网络为50、20单元；两层100单元的融合网络直接输出订货量，库存只在最后融合层输入。预测采用Softplus保证非负，提前期采用有界Sigmoid。此实现借鉴MQ-RNN结构，但没有完整实现forking-sequences训练。',
       '训练损失：标准化订货量MSE + 0.1×需求分位数pinball损失 + 0.1×标准化提前期MSE。该损失权重与辅助头属于透明披露的重建设定。默认Adam、学习率0.001、批量64、最多35轮、早停耐心8，按验证订货MSE恢复最佳权重。与原文列出的动量设置不同；代码提供SGD选项，默认交付结果没有使用该选项。',
       'BM1使用独立训练的累计需求分位数减去库存；BM2使用该PTO模型的逐日需求分位数与预测提前期；分位数只按验证窗口滚动成本选择。Normal使用正确的需求与提前期方差公式，Gamma采用矩匹配并按期末截短保护期；这是明示的实现版本，不是原笔记本逐行复刻。成本比实验对每个b/h重新生成标签、重新训练E2E。']),
      ('图表与原文的对应关系',[
       '图1展示本次实际网络；图2保留“需求曲线＋成本表”的组合；图B.1使用双纵轴；图B.2使用总成本、持有成本、缺货成本三联图；图B.3使用两组真实训练权重热图；表B.1—B.6使用三线表。保留编号和主要布局，不复制论文的结果数字。',
       '图3与表2—4重新排版的是第一阶段公开子集复算结果。图3保留公开笔记本的协变量近邻匹配；表2按笔记本h=1、b=9计费；表3采用论文公式中含截距的回归；表4采用统一指标定义及SKU对齐变化量回归的HC1误差。这些口径与原笔记本并非处处相同，已经在图注标明。它们不是新增合成现场实验。',
       '每张新增合成图表均有“SYNTHETIC METHOD RECONSTRUCTION”标记。预测样例固定选取前三个合成SKU；未挑选最准确的图。权重图真实大小为50×11，不能伪装成原文未公开特征维度。']),
      ('验证、结果解读与使用方式',[
       f'独立验证结果：{int(checks.passed.sum())}/{len(checks)} 项通过。包括12条样本路径上的事后决策与线性规划最优值核对、未来需求及实际提前期扰动不影响当前特征、成本分解、逐SKU下界和订货合法性检查。详细值保存在results/verification_summary.csv。',
       f'两次初始化的总成本分别为 {seed.iloc[0].total_cost:,.2f} 和 {seed.iloc[1].total_cost:,.2f}。这只能说明该两次运行的表现，不能据此声称排除了局部最优或证明论文结论。不同硬件的训练秒数、库版本和浮点运算也可能影响再运行结果。',
       '解压后先阅读README_中文.md；安装requirements.txt后，python run_experiments.py重新生成数据并训练全部实验；python verify_results.py核验；python render_results.py重画图表并生成报告。只想看已有结果，无需安装PyTorch：直接打开报告或figures目录。predict_demo.py可以加载已保存的模型演示单次订货预测。',
       '原始论文和公开压缩包属于用户提供资料；phase1_public目录保留第一阶段可执行复算代码、输入与结果。第二阶段data/public_*.csv为明确来源的快照。参考结构来源：Wen等，A Multi-Horizon Quantile Recurrent Forecaster（arXiv:1711.11053）；本项目不宣称使用了作者未公开实现。'])]
    doc=['<!doctype html><html lang="zh"><meta charset="utf-8"><title>E2E库存模型：合成重建结果报告</title>',
      '<style>body{font-family:system-ui,"Microsoft YaHei",sans-serif;max-width:1100px;margin:40px auto;padding:0 24px;color:#233142;line-height:1.85}h1,h2{color:#234e87}h2{margin-top:38px}img{width:100%;border:1px solid #ddd}table{border-collapse:collapse;width:100%;font-size:14px}td,th{padding:8px;border-bottom:1px solid #ddd;text-align:right}th:first-child,td:first-child{text-align:left}.tag{background:#fff2df;padding:18px;border-left:5px solid #b9652b}code{background:#f0f3f5;padding:2px 6px}</style>',
      '<h1>E2E库存模型：合成重建结果报告</h1><div class="tag">合成数据方法重建｜不是原始京东数据恢复｜全部训练结果保留</div>']
    for title,paras in sections:
        doc.append('<h2>'+title+'</h2>');doc.extend('<p>'+html.escape(p)+'</p>' for p in paras)
        if title=='交付性质与主要结果':doc.append(cost[['method','total_cost','holding_cost','stockout_cost']].to_html(index=False,float_format=lambda x:f'{x:,.2f}'))
    doc.append('<h2>论文式图表</h2>')
    for name,title in GALLERY:
        encoded=base64.b64encode((FIG/f'{name}.png').read_bytes()).decode()
        doc.append(f'<h3>{html.escape(title)}</h3><img alt="{html.escape(title)}" src="data:image/png;base64,{encoded}">')
    doc.append('</html>');(ROOT/'E2E_Phase2_Report.html').write_text('\n'.join(doc),encoding='utf-8')

    pdfmetrics.registerFont(TTFont('NotoSansSC',str(ROOT/'fonts/NotoSansSC.ttf')))
    normal=ParagraphStyle('CN',fontName='NotoSansSC',fontSize=10,leading=16,spaceAfter=8,wordWrap='CJK')
    heading=ParagraphStyle('H',parent=normal,fontSize=15,leading=22,textColor=colors.HexColor(BLUE),spaceBefore=14,spaceAfter=10,keepWithNext=True)
    title_style=ParagraphStyle('TitleCN',parent=heading,fontSize=22,leading=29,spaceAfter=18)
    story=[Paragraph('E2E库存模型：<br/>合成重建结果报告',title_style),Paragraph('合成数据方法重建 / 非原始京东数据恢复',heading)]
    for title,paras in sections:
        story.append(Paragraph(title,heading))
        for p in paras:story.append(Paragraph(html.escape(p),normal))
    story.append(PageBreak());story.append(Paragraph('论文式图表与结果',title_style))
    for name,title in GALLERY:
        from PIL import Image as PILImage
        p=FIG/f'{name}.png';w,h=PILImage.open(p).size
        story.append(KeepTogether([Paragraph(title,heading),Image(str(p),width=490,height=490*h/w),Spacer(1,10)]))
    def page(c,doc):
        c.setFont('Helvetica',8);c.setFillColor(colors.HexColor('#666666'))
        c.drawString(45,24,'E2E reconstruction | Synthetic training / released-subset diagnostics')
        c.drawRightString(A4[0]-45,24,str(doc.page))
    SimpleDocTemplate(str(ROOT/'E2E_Phase2_Report.pdf'),pagesize=A4,rightMargin=45,leftMargin=45,
                      topMargin=40,bottomMargin=42,title='E2E库存模型：合成重建结果报告',author='Reproduction workspace').build(story,onFirstPage=page,onLaterPages=page)
    print('Rendered',len(GALLERY),'figures/tables + Chinese HTML/PDF reports')

if __name__=='__main__':
    FIG.mkdir(exist_ok=True);figures()
    order=['figure_1_network','figure_2_forecasts_costs','figure_3_public_matching',
           'figure_B1_data_size','figure_B2_cost_ratio','figure_B3_weights',
           'table_B1_hyperparameters','table_B2','table_B3','table_B4','table_B5','table_B6',
           'table_2_public','table_3_public','table_4_public']
    GALLERY.sort(key=lambda item:order.index(item[0]));report()
